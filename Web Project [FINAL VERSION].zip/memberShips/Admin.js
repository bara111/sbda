<script>
$(document).ready(function() {

    $("#Link1").click(function () {

        window.location.replace("ProfilePage.php");
    });

    $("#Link3").click(function () {

        window.location.replace("signout.php");
    });





    $(".dropdown").hover(function() {

        if ($('.dropdown-content').css('display') == 'none') {
            $('.dropdown-content').show('slow');
        } else {
            $('.dropdown-content').hide('slow');
        }


    });

    $(".dropdownX").hover(function() {

        if ($('.dropdown-contentX').css('display') == 'none') {
            $('.dropdown-contentX').show('slow');
        } else {
            $('.dropdown-contentX').hide('slow');
        }


    });

    $(".dropdownXX").hover(function() {

        if ($('.dropdown-contentXX').css('display') == 'none') {
            $('.dropdown-contentXX').show('slow');
        } else {
            $('.dropdown-contentXX').hide('slow');
        }


    });
    $("#Link1A").click(function() {

        window.location.replace("Make An Appointment.php");
    });

    $("#Link2A").click(function() {

        window.location.replace("Manage Appointments.php");
    });

    $("#control_AccM").click(function() {

        window.location.replace("Accounts Management.php");
    });

    $("#control_AppM").click(function() {

        window.location.replace("Appointments Management.php");
    });

});
</script>

