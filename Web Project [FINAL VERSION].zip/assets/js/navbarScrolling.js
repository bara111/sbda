

$(document).ready(function(){       
   var scroll_start = 0;
   var startchange = $('#startchange');
   var offset = startchange.offset();
    if (startchange.length){
   $(document).scroll(function() { 
      scroll_start = $(this).scrollTop();
      if(scroll_start > offset.top) {
          $(".navbar-default").css('background', 'rgb(240,240,240,0.9)');
       } else {
          $('.navbar-default').css('background', 'transparent');
       }
   });
        
    }
    
$("#roundedImage1").mouseenter(function(){
        var img = $("#roundedImage1");
        img.animate({ width:'110px',height:'110px'}, "slow");
    });
    
    $("#roundedImage1").mouseleave(function(){
        var img = $("#roundedImage1");
        img.animate({ width:'90px',height:'90px'}, "slow");
    });
    
    $("#roundedImage2").mouseenter(function(){
        var img = $("#roundedImage2");
        img.animate({ width:'110px',height:'110px'}, "slow");
    });
    
    $("#roundedImage2").mouseleave(function(){
        var img = $("#roundedImage2");
        img.animate({ width:'90px',height:'90px'}, "slow");
    });
    
    $("#roundedImage3").mouseenter(function(){
        var img = $("#roundedImage3");
        img.animate({ width:'110px',height:'110px'}, "slow");
    });
    
    $("#roundedImage3").mouseleave(function(){
        var img = $("#roundedImage3");
        img.animate({ width:'90px',height:'90px'}, "slow");
    });
});

