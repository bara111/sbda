<?php
//fetch.php
include_once "db-connect.php";
$connect=new DbConnect();
$connect=$connect->getDb();
$output = '';

if(isset($_POST["query"]))
{
    $search = mysqli_real_escape_string($connect, $_POST["query"]);
    echo $search;
    $query = "SELECT Time FROM Appointments WHERE Date='$search'";
}
else
{
    $query = "select * from Appointments where ID='-1'";
}
$result = mysqli_query($connect, $query);
if(mysqli_num_rows($result) > 0)
{

    $output .= "<select class='form-control-lg' name='Time'>";
    $reservedTimes="";

    while ($row = mysqli_fetch_array($result)) {
        $reservedTimes.=$row['Time']."@";
    }
    $HR=8;
    $Min=00;
    for($i=0;$i<=24;$i++){
        $optionTime=$HR.":".$Min;
        if(strpos($reservedTimes,$optionTime)!==false){
            $output .= '<option disabled value="'.$HR.'">'.$optionTime." [Reserved]".'</option>';
        }else{
            $output .= '<option value="'.$HR.'">'.$HR.":".$Min.'</option>';
        }

        if(($Min+15)%60==0)
            $HR++;
        $Min=($Min+15)%60;

    }
    echo strpos($optionTime,$reservedTimes);
    $output .="</select>";


    echo $output;
}
else
{
    echo 'Please Select a Date';
}

?>